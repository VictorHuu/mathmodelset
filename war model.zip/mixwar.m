function [n]=mixwar(ry,sry,sx,y0,b,x0)
%ry 乙方射击率
%sry乙方射击有效面积
%sx甲方活动面积
%x0甲方初始人数 y0乙方初始人数
c=ry*sry/sx
n=c*y0^2-2*b*x0;
x=0:max(x0,y0)/100:max(x0,y0);
for i=1:100
    if (x*2*b+n)/c<=0
        y=0;
    else
        y=sqrt((x*2*b+n)/c);
    end
end
x1=1:max(x0,y0)/100:max(x0,y0);
y1=sqrt(abs(x1*2*b/c));
if (y0/x0)^2>2*b/(c*x0)
    disp('乙方胜！');
else if(y0/x0)^2==2*b/(c*x0)
    disp('平局！');
    else
        disp('甲方胜！');
    end
end
hold on
grid on
plot(x1,y1);
plot(x,y);
title('混合战争模型');
legend('基准线','相轨线');
hold off
%%Reference:Y.Q.Jiang. (2011). 数学模型. 152