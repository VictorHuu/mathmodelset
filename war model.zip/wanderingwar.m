function [c,d]=wanderingwar(ry,sry,sx,rx,srx,sy,x0,y0)
%ry 乙方射击率 rx 甲方射击率
%sry乙方射击有效面积 srx甲方射击有效面积
%sx甲方活动面积 xy乙方活动面积
c=ry*sry/sx;%c乙方战斗有效系数 
d=rx*srx/sy;%d甲方战斗有效系数
x=1:max(x0,y0)/100:max(x0,y0);
m=c*y0-d*x0;
y=(m+d*x)/c;
if y0/x0>d/c
    disp('乙方获胜!');
else if y0/x0==d/c
        disp('战平！');
    else
        disp('甲方获胜！');
    end
end
x1=1:max(x0,y0)/100:max(x0,y0);
hold on
plot(x1,x1);
plot(x,y);
legend('基线','人数比');
title('游击战争模型');
hold off
end
%%Reference:Y.Q.Jiang. (2011). 数学模型. 150-151.