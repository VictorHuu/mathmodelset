function [k,a,b]=generalwar(rx,px,ry,py,x0,y0)
%x0 the initial force of army A
%y0 the initial force of army B
%rx chance of shooting by army A
%ry chance of shooting by army B
%px hit ratio of army A py hit ratio of army B
b=rx*px;%b the mean killing number per time by army A
a=ry*py;%a the mean killing number per time by army B
k=a*y0^2-b*x0^2;
if k<0
    x=sqrt(-k/b):max(x0,y0)/100:max(x0,y0);
else
    x=0:max(x0,y0)/100:max(x0,y0);
end
y=sqrt(abs(k+b*x.*x)/a);
if k>0
    disp('army B win!');
else if k==0
        disp('even!');
    else
        disp('army A win!');
    end
end
hold on
grid on
x1=1:max(x0,y0)/100:max(x0,y0);
plot(x1,x1);
plot(x,y);
legend('Basic line','x-y plot');
line1=['y(t1)=',num2str(ceil(sqrt(abs(k/a)))),'x(t1")=',num2str(ceil(sqrt(abs(-k/b))))];
title(line1,'Fontsize',12);
hold off
end
%%Reference:Y.Q.Jiang. (2011). 数学模型. 149-150