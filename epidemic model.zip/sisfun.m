function dy=sisfun(t,Y,lamda,mu,N);
S=Y(1);
I=Y(2);
dy=zeros(2,1);
dy(1)=-lamda*S*I/N+mu*I;
dy(2)=-dy(1);
end
