function dy=sirfun(t,Y2,lamda,mu,N);
S=Y2(1);
I=Y2(2);
R=Y2(3);
dy=zeros(3,1);
dy(1)=-lamda*S*I/N;
dy(2)=lamda*S*I/N-mu*I;
dy(3)=mu*I;
end