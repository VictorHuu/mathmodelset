function [NumofDisease]=epidemic(t,N,i0,lamda,mode,mu)
%i0 初始病人比例
%t 传播天数
%N 总人数
%lamda 增长率
%mode 增长模型
%mu 日治愈率
%S represents susceptible,I represents infectious,R reprensents removed
%In the following methods,SIS,SIR is feasible,the others are impracitcal.
%Copyrights by Hu Yuntao,Tongji University.No copyright infringement!
T=100;
tx=0:1:T;
switch mode
    case 1%Mode1:exponential
        tx=0:1:10;
        ND=i0*N*exp(lamda*tx);
        NumofDisease=i0*N*exp(lamda*t);
        plot(tx,ND,'ro');
    case 2%model2:SI model
        ND=N./(1+(1/i0-1)*exp(-lamda*tx));
        NumofDisease=N/(1+(1/i0-1)*exp(-lamda*t));
        plot(tx,ND,'r-');
    case 3%model3:SIS model
        [T,Y] = ode45(@(t,Y)sisfun(t,Y,lamda,mu,N),[0:T],[(1-i0)*N i0*N]);
        line2=['传染病模型：SIS，日治愈率μ=',num2str(mu),'增长率λ=',num2str(lamda),'传染期接触数σ=',num2str(lamda/mu)];
        NumofDisease=Y(t,2);
        hold on
        plot(T,Y(:,1));
        plot(T,Y(:,2));
        hold off
        legend('感染人数','易感人数');
        title({line2},'Fontsize',12);
    case 4%model4:SIR model
        [T,Y2]=ode45(@(t,Y2)sirfun(t,Y2,lamda,mu,N),[0:T],[(1-i0)*N i0*N 0]);
          R2=zeros(20,1);
        for k=1:size(T+1)
            if Y2(k,3)>N
                Y2(k,3)=N;
            end
        end
        NumofDisease=ceil(Y2(t,2));
        line1=['传染病模型：SIR，日治愈率μ=',num2str(mu),'增长率λ=',num2str(lamda),'传染期接触数σ=',num2str(lamda/mu)];
        line4=['s0=',num2str(1-i0),'    i0=',num2str(i0)];
        hold on
        plot(T,ceil(Y2(:,2)));%I
        plot(T,ceil(Y2(:,1)));%S
        plot(T,ceil(Y2(:,3)));%R
        hold off
        legend('感染人数','易感人数','免疫人数');
        title({line1;line4},'Fontsize',12);
        figure 
        plot(ceil(Y2(:,1))/N,floor(Y2(:,2))/N,'*-');
        line3=['i-s图形（相轨线）;equation:',num2str(1),'-s+','1/',num2str(mu),'*ln(s/',num2str(1-i0),')'];
        title(line3);
        xlabel('i-感染率');
        ylabel('s-感染率');
        grid on
        if mu/lamda+i0<1
            line5=['当s0=1/σ=',num2str(mu/lamda),'时，i(t)达到最大值',num2str(1-1/(lamda/mu)*(1+log((lamda/mu)*(1-i0))))];
        disp(line5);
        end
        line6=['需要有',num2str((1-mu/lamda)*100),'%的人接种疫苗'];
        disp(line6);
        line7=['im=',num2str(floor(Y2(100,2))/N),'    sm=',num2str((floor(Y2(100,1)))/N)];
        disp(line7);
end
end